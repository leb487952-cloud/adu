import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Knowledge from './pages/Knowledge';
import SystemDiagram from './pages/SystemDiagram';
import QuizPage from './pages/QuizPage';
import Documents from './pages/Documents';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  return (
    <Router>
      <div className="min-h-screen bg-bg-dark flex flex-col">
        <Navbar />
        
        <main className="flex-grow">
          <AnimatePresence mode="wait">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/knowledge" element={<Knowledge />} />
              <Route path="/diagram" element={<SystemDiagram />} />
              <Route path="/quiz" element={<QuizPage />} />
              <Route path="/documents" element={<Documents />} />
            </Routes>
          </AnimatePresence>
        </main>

        <footer className="bg-bg-dark border-t border-white/10 py-10">
          <div className="max-w-7xl mx-auto px-4 text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="w-6 h-6 purple-gradient rounded flex items-center justify-center">
                <span className="text-[10px] font-bold">WR</span>
              </div>
              <span className="font-bold">WasteReview ĐHĐT</span>
            </div>
            <p className="text-text-muted text-sm">
              © 2026 Sinh viên Khoa học Môi trường - Đại học Đồng Tháp.
            </p>
            <p className="text-text-muted text-xs mt-2">
              Học tập - Sáng tạo - Bảo vệ Môi trường
            </p>
          </div>
        </footer>
      </div>
    </Router>
  );
}
