import React from 'react';
import Quiz from '../components/Quiz';
import { questions } from '../data/questions';
import { ClipboardList } from 'lucide-react';

export default function QuizPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <div className="w-16 h-16 purple-gradient rounded-2xl flex items-center justify-center mx-auto mb-6">
          <ClipboardList className="text-white w-8 h-8" />
        </div>
        <h1 className="text-4xl font-bold mb-4">Kiểm tra kiến thức</h1>
        <p className="text-text-muted max-w-2xl mx-auto">
          Làm bài trắc nghiệm 10 câu hỏi để đánh giá mức độ hiểu biết của bạn về các hệ thống xử lý chất thải.
        </p>
      </div>

      <Quiz questions={questions} />
    </div>
  );
}
