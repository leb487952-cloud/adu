import React from 'react';
import { FileText, Download, ExternalLink, Book } from 'lucide-react';

export default function Documents() {
  const docs = [
    {
      title: 'Giáo trình Công nghệ xử lý nước thải',
      type: 'PDF',
      size: '4.5 MB',
      category: 'Nước thải',
      icon: Book
    },
    {
      title: 'Slide bài giảng Quản lý chất thải rắn',
      type: 'PPTX',
      size: '12.2 MB',
      category: 'Chất thải rắn',
      icon: FileText
    },
    {
      title: 'Quy chuẩn kỹ thuật quốc gia về nước thải (QCVN 40:2011/BTNMT)',
      type: 'Link',
      size: '-',
      category: 'Pháp luật',
      icon: ExternalLink
    },
    {
      title: 'Sổ tay vận hành hệ thống xử lý khí thải công nghiệp',
      type: 'PDF',
      size: '2.1 MB',
      category: 'Khí thải',
      icon: Book
    },
    {
      title: 'Tài liệu hướng dẫn thiết kế bể UASB',
      type: 'PDF',
      size: '3.8 MB',
      category: 'Nước thải',
      icon: FileText
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold mb-4">Thư viện tài liệu</h1>
        <p className="text-text-muted">Tổng hợp các nguồn tài liệu phục vụ ôn tập và nghiên cứu.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {docs.map((doc, idx) => {
          const Icon = doc.icon;
          return (
            <div key={idx} className="glass-card p-6 flex items-center justify-between group hover:border-highlight-purple/30 transition-all">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white/5 rounded-xl flex items-center justify-center group-hover:bg-primary-purple/20 transition-colors">
                  <Icon className="text-highlight-purple w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-lg mb-1 group-hover:text-highlight-purple transition-colors">{doc.title}</h3>
                  <div className="flex items-center gap-3 text-xs text-text-muted">
                    <span className="px-2 py-0.5 bg-white/5 rounded uppercase">{doc.type}</span>
                    <span>{doc.size}</span>
                    <span className="text-highlight-purple/70">•</span>
                    <span>{doc.category}</span>
                  </div>
                </div>
              </div>
              
              <button className="p-3 bg-white/5 rounded-xl hover:bg-primary-purple text-text-muted hover:text-white transition-all">
                {doc.type === 'Link' ? <ExternalLink className="w-5 h-5" /> : <Download className="w-5 h-5" />}
              </button>
            </div>
          );
        })}
      </div>

      <div className="mt-20 glass-card p-10 bg-primary-purple/5 border-primary-purple/20">
        <div className="flex flex-col md:flex-row items-center gap-8">
          <div className="flex-1">
            <h2 className="text-2xl font-bold mb-4">Bạn có tài liệu muốn chia sẻ?</h2>
            <p className="text-text-muted mb-6">
              Hãy đóng góp tài liệu của bạn để cộng đồng sinh viên Môi trường ĐHĐT cùng học tập và phát triển.
            </p>
            <button className="px-8 py-3 purple-gradient rounded-xl font-bold">
              Gửi tài liệu ngay
            </button>
          </div>
          <div className="w-full md:w-1/3 aspect-video rounded-2xl overflow-hidden">
            <img 
              src="https://picsum.photos/seed/library/600/400" 
              alt="Library" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
